import argparse, json, numpy as np
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config, load_npz, perturb_weights, fuse, metrics
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--predictions', nargs='+', required=True); ap.add_argument('--weights', nargs='+', type=float, required=True); ap.add_argument('--output', required=True); args=ap.parse_args()
cfg=load_config(args.config); preds=[load_npz(p) for p in args.predictions]; probs=[p['probs'] for p in preds]; y=preds[0]['y_true']; out={}
for level in cfg['fusion']['perturbation_levels']:
    out[str(level)]=[metrics(fuse(probs,w), y) for w in perturb_weights(np.asarray(args.weights), level, cfg['fusion']['perturbation_trials'], cfg['fusion']['perturbation_seed'])]
Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(out, open(args.output,'w',encoding='utf-8'), indent=2)
