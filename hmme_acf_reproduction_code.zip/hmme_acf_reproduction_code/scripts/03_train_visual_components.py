import subprocess, sys, argparse
from _bootstrap import *
from hmme_acf.core import load_config
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); args=ap.parse_args(); cfg=load_config(args.config)
for m in cfg['models']['visual']:
    subprocess.check_call([sys.executable, 'scripts/02_train_model.py', '--config', args.config, '--timm-name', m['timm_name']])
