import argparse, subprocess, sys
STEPS=[['scripts/01_make_splits.py'], ['scripts/03_train_visual_components.py']]
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--dry-run', action='store_true'); args=ap.parse_args()
for s in STEPS:
    cmd=[sys.executable]+s+['--config', args.config]; print(' '.join(cmd));
    if not args.dry_run: subprocess.check_call(cmd)
