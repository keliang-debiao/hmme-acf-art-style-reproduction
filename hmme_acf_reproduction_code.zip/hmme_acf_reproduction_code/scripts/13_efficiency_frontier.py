import argparse, csv, torch
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config
from hmme_acf.torch_ops import create_model, measure_latency
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--output', required=True); args=ap.parse_args(); cfg=load_config(args.config); device='cuda' if torch.cuda.is_available() else 'cpu'
rows=[]
for m in cfg['models']['visual']:
    model=create_model(m['timm_name'], cfg['data']['num_classes'], pretrained=False); rows.append({'configuration':m['name'], 'latency_ms':measure_latency(model, device=device)})
Path(args.output).parent.mkdir(parents=True, exist_ok=True); f=open(args.output,'w',newline='',encoding='utf-8'); w=csv.DictWriter(f,fieldnames=['configuration','latency_ms']); w.writeheader(); w.writerows(rows); f.close()
