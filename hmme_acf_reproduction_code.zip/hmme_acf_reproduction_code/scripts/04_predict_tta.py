import argparse, torch
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, save_npz
from hmme_acf.torch_ops import create_model, predict_tta
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--timm-name', required=True); ap.add_argument('--checkpoint', required=True); ap.add_argument('--split', default='test'); ap.add_argument('--output', required=True); args=ap.parse_args()
cfg=load_config(args.config); model=create_model(args.timm_name, cfg['data']['num_classes'], pretrained=False); state=torch.load(args.checkpoint, map_location='cpu'); model.load_state_dict(state.get('model', state))
p,y,paths=predict_tta(model, Path(cfg['paths']['split_dir'])/(args.split+'.csv'), class_to_idx(cfg), 'cuda' if torch.cuda.is_available() else 'cpu', max(1,cfg['training']['batch_size']//4), cfg['data']['input_size'], cfg['data']['resize_short_side'])
save_npz(args.output, p, y, paths, {'model':args.timm_name,'split':args.split})
