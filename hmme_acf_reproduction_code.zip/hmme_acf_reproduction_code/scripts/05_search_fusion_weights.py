import argparse, json
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config, load_npz, search_weights, fuse, metrics
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--predictions', nargs='+', required=True); ap.add_argument('--output', required=True); args=ap.parse_args()
cfg=load_config(args.config); preds=[load_npz(p) for p in args.predictions]; y=preds[0]['y_true']; best=search_weights([p['probs'] for p in preds], y, cfg['fusion']['grid_step'], cfg['fusion']['objective'])
Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(best, open(args.output,'w',encoding='utf-8'), indent=2)
