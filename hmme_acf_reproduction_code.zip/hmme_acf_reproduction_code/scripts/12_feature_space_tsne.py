import argparse, json, numpy as np
from pathlib import Path
from _bootstrap import *
from hmme_acf.analysis import tsne_and_indices
ap=argparse.ArgumentParser(); ap.add_argument('--features', required=True); ap.add_argument('--labels', required=True); ap.add_argument('--output-prefix', required=True); args=ap.parse_args()
f=np.load(args.features); y=np.load(args.labels); emb,idx=tsne_and_indices(f,y); np.save(args.output_prefix+'_tsne.npy', emb); json.dump(idx, open(args.output_prefix+'_indices.json','w',encoding='utf-8'), indent=2)
