import argparse, json
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_npz, metrics
from hmme_acf.analysis import mcnemar_test, bootstrap_metric
ap=argparse.ArgumentParser(); ap.add_argument('--model-a', required=True); ap.add_argument('--model-b', required=True); ap.add_argument('--output', required=True); args=ap.parse_args()
a=load_npz(args.model_a); b=load_npz(args.model_b); y=a['y_true']
out={'mcnemar':mcnemar_test(a['probs'], b['probs'], y), 'bootstrap_a_top1':bootstrap_metric(a['probs'], y, lambda p,yy: metrics(p,yy)['top1']), 'bootstrap_b_top1':bootstrap_metric(b['probs'], y, lambda p,yy: metrics(p,yy)['top1'])}
Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(out, open(args.output,'w',encoding='utf-8'), indent=2)
