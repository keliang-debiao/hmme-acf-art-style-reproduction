import argparse, torch, numpy as np
from pathlib import Path
from torch.utils.data import DataLoader
from torch import nn
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, load_npz
from hmme_acf.torch_ops import ManifestDataset, train_transform, create_model
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--teacher-train-predictions', required=True); args=ap.parse_args()
cfg=load_config(args.config); device='cuda' if torch.cuda.is_available() else 'cpu'; c2i=class_to_idx(cfg); teacher=torch.tensor(load_npz(args.teacher_train_predictions)['probs'], dtype=torch.float32)
ds=ManifestDataset(Path(cfg['paths']['split_dir'])/'train.csv', c2i, train_transform(), return_path=True); loader=DataLoader(ds,batch_size=cfg['training']['batch_size'],shuffle=False,num_workers=cfg['training']['num_workers'])
student=create_model(cfg['distillation']['student_timm_name'], cfg['data']['num_classes'], pretrained=True).to(device); opt=torch.optim.AdamW(student.parameters(),lr=cfg['training']['lr'],weight_decay=cfg['training']['weight_decay']); ce=nn.CrossEntropyLoss(); kl=nn.KLDivLoss(reduction='batchmean'); T=cfg['distillation']['temperature']; alpha=cfg['distillation']['alpha']
for _ in range(cfg['distillation']['epochs']):
    student.train(); offset=0
    for x,y,_ in loader:
        bs=x.shape[0]; tp=teacher[offset:offset+bs].to(device); offset+=bs; x,y=x.to(device),y.to(device); opt.zero_grad(set_to_none=True); logits=student(x)
        loss=alpha*ce(logits,y)+(1-alpha)*(T**2)*kl(torch.log_softmax(logits/T,1), torch.softmax(torch.log(torch.clamp(tp,min=1e-8))/T,1)); loss.backward(); opt.step()
out=Path(cfg['paths']['checkpoint_dir'])/'distilled_convnext_small.pt'; out.parent.mkdir(parents=True, exist_ok=True); torch.save({'model':student.state_dict()}, out)
