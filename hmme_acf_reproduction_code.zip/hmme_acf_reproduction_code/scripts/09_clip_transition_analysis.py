import argparse, json
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_npz
from hmme_acf.analysis import transition
ap=argparse.ArgumentParser(); ap.add_argument('--before', required=True); ap.add_argument('--after', required=True); ap.add_argument('--output', required=True); args=ap.parse_args()
b=load_npz(args.before); a=load_npz(args.after); out=transition(b['probs'], a['probs'], b['y_true']); Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(out, open(args.output,'w',encoding='utf-8'), indent=2)
