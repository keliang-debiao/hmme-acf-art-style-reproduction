import argparse, json
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, load_npz, aggregate_probs, map_y, metrics
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--predictions', required=True); ap.add_argument('--taxonomy', default='main', choices=['main','chronology_oriented','visual_affinity_oriented']); ap.add_argument('--output', required=True); args=ap.parse_args()
cfg=load_config(args.config); pred=load_npz(args.predictions); c2i=class_to_idx(cfg)
maps={k:cfg['hierarchy'][k] for k in ['period_3','family_4','family_5']} if args.taxonomy=='main' else cfg['hierarchy']['alternatives'][args.taxonomy]
out={}
for h,m in maps.items():
    hp, groups=aggregate_probs(pred['probs'], m, c2i); hy,_=map_y(pred['y_true'], m, c2i); out[h]={'groups':groups, 'metrics':metrics(hp,hy,groups)}
Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(out, open(args.output,'w',encoding='utf-8'), indent=2)
