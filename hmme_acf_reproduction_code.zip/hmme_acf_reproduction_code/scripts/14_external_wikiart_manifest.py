import argparse, pandas as pd
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_config
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--output', required=True); args=ap.parse_args(); cfg=load_config(args.config)
df=pd.read_csv(cfg['paths']['wikiart_manifest']); df=df[df['label'].isin(cfg['external']['wikiart_observed_classes'])]; Path(args.output).parent.mkdir(parents=True, exist_ok=True); df.to_csv(args.output,index=False)
