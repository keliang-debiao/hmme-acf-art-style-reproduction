import argparse, torch
from pathlib import Path
from torch.utils.data import DataLoader
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, seed_everything
from hmme_acf.torch_ops import ManifestDataset, train_transform, val_transform, create_model, fit
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--timm-name', required=True); ap.add_argument('--seed', type=int); args=ap.parse_args()
cfg=load_config(args.config); seed_everything(args.seed or cfg['project']['seed'], cfg['training']['deterministic']); c2i=class_to_idx(cfg)
tr=ManifestDataset(Path(cfg['paths']['split_dir'])/'train.csv', c2i, train_transform(cfg['data']['input_size'], cfg['data']['resize_short_side'], tuple(cfg['training']['scale_jitter']), cfg['training']['brightness_contrast_jitter']))
va=ManifestDataset(Path(cfg['paths']['split_dir'])/'val.csv', c2i, val_transform(cfg['data']['input_size'], cfg['data']['resize_short_side']))
loader=lambda ds,shuf: DataLoader(ds,batch_size=cfg['training']['batch_size'],shuffle=shuf,num_workers=cfg['training']['num_workers'])
model=create_model(args.timm_name, cfg['data']['num_classes'], pretrained=True)
ckpt=Path(cfg['paths']['checkpoint_dir'])/(args.timm_name.replace('/','_')+'.pt')
fit(model, loader(tr,True), loader(va,False), 'cuda' if torch.cuda.is_available() else 'cpu', cfg, ckpt)
