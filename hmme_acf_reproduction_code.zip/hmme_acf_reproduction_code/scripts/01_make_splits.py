import argparse
from _bootstrap import *
from hmme_acf.core import load_config, class_names, build_splits, ensure_dirs
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--no-verify', action='store_true'); args=ap.parse_args()
cfg=load_config(args.config); ensure_dirs(cfg)
build_splits(cfg['paths']['artbench_root'], cfg['paths']['split_dir'], class_names(cfg), cfg['data']['train_val_ratio'], cfg['project']['seed'], verify=not args.no_verify)
