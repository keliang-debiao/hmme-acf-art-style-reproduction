import argparse, torch, numpy as np
from pathlib import Path
from torch import nn
from torch.utils.data import DataLoader
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, class_names, save_npz
from hmme_acf.torch_ops import ManifestDataset
try:
    import open_clip
except ImportError as exc:
    raise SystemExit('Install open_clip_torch to run CLIP experiments.') from exc

class ClipHead(nn.Module):
    def __init__(self, clip_model, embed_dim, num_classes, freeze=False):
        super().__init__(); self.clip=clip_model; self.head=nn.Linear(embed_dim,num_classes)
        if freeze:
            for p in self.clip.visual.parameters(): p.requires_grad=False
    def forward(self,x):
        f=self.clip.encode_image(x); f=f/f.norm(dim=-1, keepdim=True); return self.head(f.float())

@torch.no_grad()
def predict(model, loader, device):
    ps=[]; ys=[]; model.eval()
    for x,y in loader:
        x=x.to(device); ps.append(torch.softmax(model(x),1).cpu().numpy()); ys.append(y.numpy())
    return np.concatenate(ps), np.concatenate(ys)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--mode', choices=['zero_shot','linear_probe','fine_tune'], required=True); ap.add_argument('--output', required=True); args=ap.parse_args()
    cfg=load_config(args.config); device='cuda' if torch.cuda.is_available() else 'cpu'; c2i=class_to_idx(cfg)
    clip, _, preprocess = open_clip.create_model_and_transforms(cfg['clip']['model_name'], pretrained=cfg['clip']['pretrained']); tok=open_clip.get_tokenizer(cfg['clip']['model_name']); clip.to(device)
    if args.mode=='zero_shot':
        prompts=[cfg['clip']['prompt_template'].format(class_name=c.replace('_',' ')) for c in class_names(cfg)]; text=tok(prompts).to(device)
        with torch.no_grad():
            tf=clip.encode_text(text); tf=tf/tf.norm(dim=-1,keepdim=True)
        ds=ManifestDataset(Path(cfg['paths']['split_dir'])/'test.csv', c2i, preprocess); loader=DataLoader(ds,batch_size=cfg['training']['batch_size'],shuffle=False,num_workers=cfg['training']['num_workers'])
        ps=[]; ys=[]
        for x,y in loader:
            with torch.no_grad():
                im=clip.encode_image(x.to(device)); im=im/im.norm(dim=-1,keepdim=True); ps.append(torch.softmax(im@tf.T,1).cpu().numpy()); ys.append(y.numpy())
        save_npz(args.output, np.concatenate(ps), np.concatenate(ys)); return
    dummy=torch.zeros(1,3,224,224,device=device)
    with torch.no_grad(): dim=clip.encode_image(dummy).shape[-1]
    model=ClipHead(clip, int(dim), cfg['data']['num_classes'], freeze=(args.mode=='linear_probe')).to(device)
    tr=ManifestDataset(Path(cfg['paths']['split_dir'])/'train.csv', c2i, preprocess); loader=DataLoader(tr,batch_size=cfg['training']['batch_size'],shuffle=True,num_workers=cfg['training']['num_workers'])
    opt=torch.optim.AdamW(filter(lambda p:p.requires_grad, model.parameters()), lr=cfg['training']['lr'], weight_decay=cfg['training']['weight_decay']); ce=nn.CrossEntropyLoss()
    for _ in range(cfg['clip'][args.mode+'_epochs']):
        model.train()
        for x,y in loader:
            x,y=x.to(device),y.to(device); opt.zero_grad(set_to_none=True); loss=ce(model(x),y); loss.backward(); opt.step()
    torch.save({'model':model.state_dict()}, Path(cfg['paths']['checkpoint_dir'])/f'clip_{args.mode}.pt')

if __name__=='__main__': main()
