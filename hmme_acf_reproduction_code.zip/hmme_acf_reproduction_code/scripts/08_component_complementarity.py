import argparse, json
from pathlib import Path
from _bootstrap import *
from hmme_acf.core import load_npz
from hmme_acf.analysis import complementarity, recovery
ap=argparse.ArgumentParser(); ap.add_argument('--predictions', nargs='+', required=True); ap.add_argument('--names', nargs='+', required=True); ap.add_argument('--primary-index', type=int, default=0); ap.add_argument('--output', required=True); args=ap.parse_args()
ps=[load_npz(p) for p in args.predictions]; probs=[p['probs'] for p in ps]; y=ps[0]['y_true']; out=complementarity(probs,y,args.names); out['recovery_primary']=recovery(probs[args.primary_index], [p for i,p in enumerate(probs) if i!=args.primary_index], y)
Path(args.output).parent.mkdir(parents=True, exist_ok=True); json.dump(out, open(args.output,'w',encoding='utf-8'), indent=2)
