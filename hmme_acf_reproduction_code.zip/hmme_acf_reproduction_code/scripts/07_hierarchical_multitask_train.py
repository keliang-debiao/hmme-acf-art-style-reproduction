import argparse, torch
from pathlib import Path
from torch.utils.data import DataLoader
from _bootstrap import *
from hmme_acf.core import load_config, class_to_idx, seed_everything
from hmme_acf.torch_ops import ManifestDataset, train_transform, create_model, hierarchical_loss
ap=argparse.ArgumentParser(); ap.add_argument('--config', default='configs/default.yaml'); ap.add_argument('--timm-name', required=True); ap.add_argument('--lambda-h', type=float, required=True); args=ap.parse_args()
cfg=load_config(args.config); seed_everything(cfg['project']['seed'], cfg['training']['deterministic']); device='cuda' if torch.cuda.is_available() else 'cpu'; c2i=class_to_idx(cfg); maps={k:cfg['hierarchy'][k] for k in ['period_3','family_4','family_5']}
ds=ManifestDataset(Path(cfg['paths']['split_dir'])/'train.csv', c2i, train_transform()); loader=DataLoader(ds,batch_size=cfg['training']['batch_size'],shuffle=True,num_workers=cfg['training']['num_workers'])
model=create_model(args.timm_name, cfg['data']['num_classes'], pretrained=True).to(device); opt=torch.optim.AdamW(model.parameters(),lr=cfg['training']['lr'],weight_decay=cfg['training']['weight_decay'])
for _ in range(cfg['training']['epochs']):
    model.train()
    for x,y in loader:
        x,y=x.to(device),y.to(device); opt.zero_grad(set_to_none=True); loss=hierarchical_loss(model(x), y, maps, c2i, args.lambda_h); loss.backward(); opt.step()
out=Path(cfg['paths']['checkpoint_dir'])/(args.timm_name.replace('/','_')+f'_hier_{args.lambda_h}.pt'); out.parent.mkdir(parents=True, exist_ok=True); torch.save({'model':model.state_dict(),'lambda_h':args.lambda_h}, out)
