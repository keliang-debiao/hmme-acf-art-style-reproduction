from __future__ import annotations
import numpy as np
from sklearn.metrics import silhouette_score, normalized_mutual_info_score, davies_bouldin_score
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from statsmodels.stats.contingency_tables import mcnemar


def q_stat(pred_a, pred_b, y):
    a=pred_a==y; b=pred_b==y; n11=np.sum(a&b); n00=np.sum(~a&~b); n10=np.sum(a&~b); n01=np.sum(~a&b); den=n11*n00+n10*n01
    return 0.0 if den==0 else float((n11*n00-n10*n01)/den)

def complementarity(prob_list, y, names):
    preds=[p.argmax(1) for p in prob_list]; rows=[]
    for i in range(len(preds)):
        for j in range(i+1,len(preds)):
            ea=(preds[i]!=y).astype(float); eb=(preds[j]!=y).astype(float)
            corr=0.0 if ea.std()==0 or eb.std()==0 else float(np.corrcoef(ea,eb)[0,1])
            rows.append({'model_a':names[i], 'model_b':names[j], 'disagreement':float(np.mean(preds[i]!=preds[j])), 'q_statistic':q_stat(preds[i],preds[j],y), 'error_correlation':corr, 'double_fault':float(np.mean((preds[i]!=y)&(preds[j]!=y)))})
    correct_any=np.zeros_like(y,dtype=bool)
    for pred in preds: correct_any |= pred==y
    return {'pairwise':rows, 'oracle_accuracy':float(correct_any.mean())}

def recovery(primary_probs, other_probs, y):
    pp=primary_probs.argmax(1); wrong=pp!=y; rec_any=np.zeros_like(y,dtype=bool); per=[]
    for p in other_probs:
        r=wrong & (p.argmax(1)==y); rec_any |= r; per.append({'recovered':int(r.sum()), 'rate':float(r.sum()/max(1,wrong.sum()))})
    return {'primary_errors':int(wrong.sum()), 'union_recovered':int((wrong&rec_any).sum()), 'union_rate':float((wrong&rec_any).sum()/max(1,wrong.sum())), 'per_model':per}

def transition(before_probs, after_probs, y):
    a=before_probs.argmax(1); b=after_probs.argmax(1)
    return {'wrong_to_correct':int(((a!=y)&(b==y)).sum()), 'correct_to_wrong':int(((a==y)&(b!=y)).sum()), 'both_correct':int(((a==y)&(b==y)).sum()), 'both_wrong':int(((a!=y)&(b!=y)).sum())}

def mcnemar_test(probs_a, probs_b, y):
    a=probs_a.argmax(1)==y; b=probs_b.argmax(1)==y; table=np.array([[np.sum(a&b), np.sum(a&~b)], [np.sum(~a&b), np.sum(~a&~b)]])
    res=mcnemar(table, exact=False, correction=True); return {'table':table.tolist(), 'statistic':float(res.statistic), 'pvalue':float(res.pvalue)}

def bootstrap_metric(probs, y, metric_fn, trials=10000, seed=42):
    rng=np.random.default_rng(seed); vals=[]; n=len(y)
    for _ in range(trials):
        idx=rng.integers(0,n,n); vals.append(metric_fn(probs[idx], y[idx]))
    return {'mean':float(np.mean(vals)), 'lower':float(np.quantile(vals,0.025)), 'upper':float(np.quantile(vals,0.975))}

def tsne_and_indices(features, labels, pca_dim=50, perplexity=30, learning_rate=200, n_iter=1000, seed=42):
    f=features/np.maximum(np.linalg.norm(features,axis=1,keepdims=True),1e-12)
    fp=PCA(n_components=min(pca_dim,f.shape[1]), random_state=seed).fit_transform(f) if f.shape[1]>pca_dim else f
    emb=TSNE(n_components=2, perplexity=perplexity, learning_rate=learning_rate, n_iter=n_iter, init='pca', random_state=seed).fit_transform(fp)
    idx={'silhouette':float(silhouette_score(f,labels)), 'davies_bouldin':float(davies_bouldin_score(f,labels)), 'nmi_self':float(normalized_mutual_info_score(labels,labels))}
    return emb, idx
