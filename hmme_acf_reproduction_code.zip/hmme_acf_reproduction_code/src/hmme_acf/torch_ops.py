from __future__ import annotations
from pathlib import Path
import math, time
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.transforms import functional as F
from PIL import Image
import timm

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

class ManifestDataset(Dataset):
    def __init__(self, manifest, class_to_idx, transform=None, return_path=False):
        import pandas as pd
        self.df = pd.read_csv(manifest); self.c2i = class_to_idx; self.transform = transform; self.return_path = return_path
    def __len__(self): return len(self.df)
    def __getitem__(self, i):
        row = self.df.iloc[i]
        with Image.open(row.path) as img: img = img.convert("RGB")
        if self.transform: img = self.transform(img)
        y = self.c2i[row.label]
        return (img, y, row.path) if self.return_path else (img, y)

def train_transform(input_size=224, resize_short_side=256, scale_jitter=(0.8,1.2), bc_jitter=0.10):
    return transforms.Compose([
        transforms.Resize(resize_short_side, interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.RandomResizedCrop(input_size, scale=scale_jitter, interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.RandomHorizontalFlip(), transforms.ColorJitter(brightness=bc_jitter, contrast=bc_jitter),
        transforms.ToTensor(), transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD)])

def val_transform(input_size=224, resize_short_side=256):
    return transforms.Compose([transforms.Resize(resize_short_side, interpolation=transforms.InterpolationMode.BICUBIC), transforms.CenterCrop(input_size), transforms.ToTensor(), transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD)])

class FourteenViewTTA:
    def __init__(self, input_size=224, resize_short_side=256): self.input_size=input_size; self.resize_short_side=resize_short_side
    def __call__(self, img):
        img = F.resize(img, self.resize_short_side, interpolation=transforms.InterpolationMode.BICUBIC)
        crops = list(transforms.FiveCrop(self.input_size)(img)); views=[]
        for crop in crops: views += [crop, F.hflip(crop)]
        center = F.center_crop(img, [self.input_size, self.input_size])
        views += [F.adjust_brightness(center,1.05), F.adjust_brightness(center,0.95), F.adjust_contrast(center,1.05), F.adjust_contrast(center,0.95)]
        return torch.stack([F.normalize(F.to_tensor(v), IMAGENET_MEAN, IMAGENET_STD) for v in views])

def create_model(timm_name, num_classes=10, pretrained=True):
    return timm.create_model(timm_name, pretrained=pretrained, num_classes=num_classes)

def scheduler(optimizer, warmup_epochs, epochs):
    def f(ep):
        if ep < warmup_epochs: return float(ep+1)/max(1,warmup_epochs)
        p = float(ep-warmup_epochs)/max(1, epochs-warmup_epochs)
        return 0.5*(1+math.cos(math.pi*p))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, f)

@torch.no_grad()
def predict(model, loader, device):
    model.eval(); ps=[]; ys=[]
    for x,y in loader:
        x=x.to(device); logits=model(x); ps.append(torch.softmax(logits,1).cpu()); ys.append(y.cpu())
    return torch.cat(ps).numpy(), torch.cat(ys).numpy()

def fit(model, train_loader, val_loader, device, cfg, ckpt_path):
    from .core import metrics
    model.to(device); opt=torch.optim.AdamW(model.parameters(), lr=cfg['training']['lr'], weight_decay=cfg['training']['weight_decay'])
    sch=scheduler(opt, cfg['training']['warmup_epochs'], cfg['training']['epochs']); ce=nn.CrossEntropyLoss()
    scaler=torch.cuda.amp.GradScaler() if cfg['training'].get('mixed_precision', True) and str(device).startswith('cuda') else None
    best=-1; bad=0
    for ep in range(cfg['training']['epochs']):
        model.train()
        for x,y in train_loader:
            x,y=x.to(device), y.to(device); opt.zero_grad(set_to_none=True)
            if scaler:
                with torch.cuda.amp.autocast(): loss=ce(model(x), y)
                scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
            else:
                loss=ce(model(x), y); loss.backward(); opt.step()
        sch.step(); vp,vy=predict(model, val_loader, device); score=metrics(vp,vy)['balanced_accuracy']
        if score>best:
            best=score; bad=0; Path(ckpt_path).parent.mkdir(parents=True, exist_ok=True); torch.save({'model':model.state_dict(),'score':score,'epoch':ep}, ckpt_path)
        else:
            bad+=1
            if bad>=cfg['training']['early_stopping_patience']: break

@torch.no_grad()
def predict_tta(model, manifest, c2i, device, batch_size=16, input_size=224, resize_short_side=256):
    import pandas as pd
    df=pd.read_csv(manifest); tta=FourteenViewTTA(input_size, resize_short_side); model.to(device).eval()
    allp=[]; ally=[]; paths=[]
    for s in range(0,len(df),batch_size):
        rows=df.iloc[s:s+batch_size]; views=[]; ys=[]
        for _,row in rows.iterrows():
            with Image.open(row.path) as img: img=img.convert('RGB')
            views.append(tta(img)); ys.append(c2i[row.label]); paths.append(row.path)
        x=torch.stack(views); b,v,c,h,w=x.shape; logits=model(x.view(b*v,c,h,w).to(device))
        allp.append(torch.softmax(logits,1).view(b,v,-1).mean(1).cpu().numpy()); ally.append(np.asarray(ys))
    return np.concatenate(allp), np.concatenate(ally), paths

def child_matrix(mapping, c2i, device):
    mat=torch.zeros(len(mapping), len(c2i), device=device)
    for gi, children in enumerate(mapping.values()):
        for c in children: mat[gi, c2i[c]]=1
    return mat

def coarse_targets(y, mapping, c2i, device):
    f2g={c2i[c]:gi for gi,children in enumerate(mapping.values()) for c in children}
    return torch.tensor([f2g[int(v)] for v in y.detach().cpu()], dtype=torch.long, device=device)

def hierarchical_loss(logits, y, mappings, c2i, lambda_h):
    ce=nn.CrossEntropyLoss(); probs=torch.softmax(logits,1); losses=[]
    for mapping in mappings.values():
        mat=child_matrix(mapping,c2i,logits.device); cp=probs@mat.T; clog=torch.log(torch.clamp(cp, min=1e-8))
        losses.append(ce(clog, coarse_targets(y,mapping,c2i,logits.device)))
    return ce(logits,y)+(lambda_h/len(losses))*sum(losses)

def measure_latency(model, device='cuda', repeats=100, warmup=20):
    device=torch.device(device); model.to(device).eval(); x=torch.randn(1,3,224,224,device=device)
    for _ in range(warmup): model(x)
    if device.type=='cuda': torch.cuda.synchronize()
    t=time.perf_counter()
    for _ in range(repeats): model(x)
    if device.type=='cuda': torch.cuda.synchronize()
    return 1000*(time.perf_counter()-t)/repeats
