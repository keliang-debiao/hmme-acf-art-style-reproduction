from __future__ import annotations
from pathlib import Path
import os, json, random, math, time
import yaml
import numpy as np
import pandas as pd
from PIL import Image, UnidentifiedImageError
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, balanced_accuracy_score, precision_recall_fscore_support

VALID_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dirs(cfg):
    for k in ["work_dir", "split_dir", "checkpoint_dir", "prediction_dir", "figure_dir"]:
        Path(cfg["paths"][k]).mkdir(parents=True, exist_ok=True)


def class_names(cfg):
    return list(cfg["data"]["class_names"])


def class_to_idx(cfg):
    return {c: i for i, c in enumerate(class_names(cfg))}


def seed_everything(seed=42, deterministic=True):
    import torch
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def scan_imagefolder(root):
    root = Path(root)
    rows = []
    for class_dir in sorted(p for p in root.iterdir() if p.is_dir()):
        for fp in sorted(class_dir.rglob("*")):
            if fp.suffix.lower() in VALID_EXTENSIONS:
                rows.append({"path": str(fp), "label": class_dir.name})
    if not rows:
        raise FileNotFoundError(f"No images found under {root}")
    return pd.DataFrame(rows)


def verify_images(df):
    ok = []
    for p in df["path"]:
        try:
            with Image.open(p) as img:
                img.convert("RGB")
            ok.append(True)
        except (UnidentifiedImageError, OSError):
            ok.append(False)
    return df.loc[ok].reset_index(drop=True)


def build_splits(artbench_root, split_dir, classes, train_val_ratio=0.9, seed=42, verify=True):
    root, out = Path(artbench_root), Path(split_dir)
    out.mkdir(parents=True, exist_ok=True)
    train_df, test_df = scan_imagefolder(root / "train"), scan_imagefolder(root / "test")
    if verify:
        train_df, test_df = verify_images(train_df), verify_images(test_df)
    classes = set(classes)
    train_df = train_df[train_df.label.isin(classes)].reset_index(drop=True)
    test_df = test_df[test_df.label.isin(classes)].reset_index(drop=True)
    tr, va = train_test_split(train_df, train_size=train_val_ratio, stratify=train_df.label, random_state=seed)
    for name, df in [("train", tr), ("val", va), ("test", test_df)]:
        df.sort_values(["label", "path"]).to_csv(out / f"{name}.csv", index=False)


def save_npz(path, probs, y_true, paths=None, meta=None):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"probs": probs.astype("float32"), "y_true": y_true.astype("int64")}
    if paths is not None: payload["paths"] = np.asarray(paths)
    if meta is not None: payload["meta"] = np.asarray(json.dumps(meta))
    np.savez_compressed(path, **payload)


def load_npz(path):
    z = np.load(path, allow_pickle=True)
    return {k: z[k] for k in z.files}


def metrics(probs, y_true, names=None):
    pred = probs.argmax(1)
    p, r, f, s = precision_recall_fscore_support(y_true, pred, labels=np.arange(probs.shape[1]), zero_division=0)
    out = {
        "top1": float(accuracy_score(y_true, pred)),
        "accuracy": float(accuracy_score(y_true, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, pred)),
        "macro_precision": float(p.mean()),
        "macro_recall": float(r.mean()),
        "macro_f1": float(f.mean()),
    }
    if probs.shape[1] >= 3: out["top3"] = topk(probs, y_true, 3)
    if probs.shape[1] >= 5: out["top5"] = topk(probs, y_true, 5)
    names = names or [str(i) for i in range(probs.shape[1])]
    out["per_class"] = [{"class": names[i], "precision": float(p[i]), "recall": float(r[i]), "f1": float(f[i]), "support": int(s[i])} for i in range(len(names))]
    return out


def topk(probs, y_true, k):
    idx = np.argsort(probs, axis=1)[:, -k:]
    return float(np.mean([int(y_true[i]) in idx[i] for i in range(len(y_true))]))


def group_indices(mapping, c2i):
    groups = list(mapping.keys())
    return groups, [[c2i[c] for c in mapping[g]] for g in groups]


def aggregate_probs(probs, mapping, c2i):
    groups, idxs = group_indices(mapping, c2i)
    out = np.zeros((len(probs), len(groups)), dtype=float)
    for j, ii in enumerate(idxs):
        out[:, j] = probs[:, ii].sum(1)
    return out, groups


def map_y(y, mapping, c2i):
    groups, idxs = group_indices(mapping, c2i)
    f2g = {i: gi for gi, ii in enumerate(idxs) for i in ii}
    return np.asarray([f2g[int(v)] for v in y], dtype=int), groups


def weight_grid(n, step):
    units = int(round(1.0 / step))
    def rec(k, rem):
        if k == 1: yield [rem]
        else:
            for i in range(rem + 1):
                for tail in rec(k - 1, rem - i): yield [i] + tail
    for counts in rec(n, units):
        yield np.asarray(counts, dtype=float) * step


def fuse(prob_list, weights):
    w = np.asarray(weights, dtype=float); w = w / w.sum()
    out = np.zeros_like(prob_list[0], dtype=float)
    for p, wi in zip(prob_list, w): out += wi * p
    return out


def search_weights(prob_list, y_true, step=0.05, objective="balanced_accuracy"):
    best = {"score": -1, "weights": None, "metrics": None}
    for w in weight_grid(len(prob_list), step):
        m = metrics(fuse(prob_list, w), y_true)
        if m[objective] > best["score"]: best = {"score": m[objective], "weights": w.tolist(), "metrics": m}
    return best


def perturb_weights(weights, level, trials, seed=2026):
    rng = np.random.default_rng(seed); weights = np.asarray(weights, dtype=float)
    out = []
    for _ in range(trials):
        w = weights * (1 + rng.uniform(-level, level, len(weights)))
        w = np.maximum(w, 0); w = w / w.sum()
        out.append(w)
    return np.asarray(out)
